echo 'I am a virus. You have been pwned!! Terminate me if you can!!'
echo '#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/prctl.h>
#include<stdlib.h>
#include<sys/wait.h>

void createproc(int a, char n)
{
    
    pid_t ppid_before_fork = getpid();
    pid_t pid = fork();

    if(pid)
    {
        //parent
        wait(NULL);
        createproc(1, n);
    }
    else
    {
        char s[6];
		sprintf(s, "WORM%c", (char)(n+1));
		prctl(PR_SET_NAME, s);
        while(getppid()==ppid_before_fork);
		char p[6];
		sprintf(p, "WORM%c", n);
		prctl(PR_SET_NAME, p);
        createproc(0, n);
    }
}

int main(int argc, char **argv)
{
    int child;
    int ctr = 1;
	char num = argv[1][0];
    child = fork();
    if(child==-1)
    {
        perror("fork");
        return 0;
    }
    else if(child==0)
    {
        //prctl(PR_SET_NAME, "WORM0");
        printf("Hello");
        createproc(1, num);

        /*for(int i=0;i<5;i++) // loop will run n times (n=5)
        {
            createproc();
        }
        for(int i=0;i<5;i++) // loop will run n times (n=5)
        {
            if(i!=0)
            {
                sleep(1);
                createproc();
                createproc();
                i=0;
            }
            wait(NULL);
        }*/

    }
    else
    {
        //printf("It is a virus. You have been pwned!!\n");
        return 0;
    }
    return 0;
}' > temp.c

gcc temp.c -o WORM0
gcc temp.c -o WORM2
gcc temp.c -o WORM4

./WORM0 0
./WORM2 2
./WORM4 4

rm temp.c WORM0 WORM2 WORM4
